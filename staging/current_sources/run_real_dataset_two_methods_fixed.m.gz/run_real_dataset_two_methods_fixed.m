function results = run_real_dataset_two_methods_fixed_fixed(dataset_root, user_cfg)
% RUN_REAL_DATASET_TWO_METHODS
%
% Evaluate the current Downsampling and Patch ideas on the anomaly datasets
% recently added under:
%
%   report/可能有用/
%
% The code is intentionally self-contained and does NOT require System
% Identification Toolbox.  These benchmark datasets contain only observed
% time-series channels and do not provide a physical exogenous input u(k),
% so a continuous-time transfer function estimated by tfest is not
% identifiable in the same sense as in the paper's simulation experiment.
% For these datasets we therefore use a one-step multivariate
% autoregressive predictor (VAR with an automatically selected lag
% structure) as the common identification model.  The two outlier
% detection methods differ in how the model parameters and residual
% outliers are handled:
%
%   Downsampling:
%     1) use a fixed lag structure selected without test labels;
%     2) search K-way downsampled target-index subsets for a clean model;
%     3) evaluate the accepted model on the complete record;
%     4) detect with median + consistency-corrected MAD and a gamma
%        multiplier calibrated from training data when available.
%
%   Patch:
%     1) use the same fixed lag structure;
%     2) identify a robust initial model;
%     3) form complete-record one-step residuals;
%     4) compute overlapping local quadratic Patch residual scores;
%     5) detect using a Patch gamma calibrated from training data;
%     6) repair detected samples with model prediction + local residual
%        trend and re-identify, up to a small number of outer iterations.
%
% Training / validation protocol
% ------------------------------
% If a dataset folder contains train_no_anomaly.csv and train_anomaly.csv:
%   - model lag structure is selected using train_no_anomaly.csv;
%   - gamma values are tuned using train_anomaly.csv labels ONLY;
%   - test.csv labels are used ONLY for final evaluation.
%
% If only train_no_anomaly.csv exists:
%   - structure is selected from that normal training set;
%   - gamma is calibrated to a target training false-positive rate.
%
% If only train_anomaly.csv exists:
%   - normal labelled rows are used for structure selection;
%   - gamma is tuned on the labelled training record.
%
% If no training file exists (e.g. CalIt2 / Dodgers in the current repo):
%   - structure is estimated robustly from test.csv WITHOUT using labels;
%   - fixed unsupervised gamma defaults are used;
%   - test labels are still used only after detection for TP/TN/FP/FN.
%
% Metrics
% -------
% Point-wise TP, TN, FP, FN, Precision, Recall, Specificity, F1,
% Accuracy, BalancedAccuracy and MCC are written for each method.
%
% Usage
% -----
% From the root of a local clone of isheach/report:
%
%   results = run_real_dataset_two_methods_fixed;
%
% or:
%
%   results = run_real_dataset_two_methods_fixed(fullfile(pwd,'可能有用'));
%
% Optional:
%
%   cfg = struct;
%   cfg.DatasetFilter = ["CalIt2","Dodgers","GutenTAG/ecg-noise-10%"];
%   results = run_real_dataset_two_methods_fixed(fullfile(pwd,'可能有用'), cfg);
%
% Output
% ------
%   real_dataset_two_method_results_fixed/
%       real_dataset_two_method_results_fixed.xlsx
%       real_dataset_two_method_results_fixed.mat
%
% The XLSX file contains:
%   Summary     - one row per dataset and method
%   Tuning      - selected lag structure and threshold calibration
%   DatasetInfo - input files and dimensions
%   Failures    - datasets that could not be processed
%
% -------------------------------------------------------------------------
% Important interpretation note
% -------------------------------------------------------------------------
% This benchmark adaptation tests the Downsampling/Patch OUTLIER-DETECTION
% framework on generic time-series datasets.  It does not claim that a
% physical continuous-time transfer function G(s) exists for datasets that
% have no exogenous input.  The original tfest-based simulation experiment
% should remain the experiment used to validate continuous-time parameter
% identification.
%

if nargin < 1 || isempty(dataset_root)
    dataset_root = fullfile(pwd, '可能有用');
end

if nargin < 2
    user_cfg = struct();
end

cfg = default_config();
cfg = merge_struct(cfg, user_cfg);

if ~isfolder(dataset_root)
    error('realbench:DatasetRootNotFound', ...
        'Dataset root does not exist: %s', dataset_root);
end

fprintf('============================================================\n');
fprintf(' Real anomaly-dataset benchmark: Downsampling vs Patch\n');
fprintf('============================================================\n');
fprintf('Dataset root: %s\n', dataset_root);

specs = discover_datasets(dataset_root, cfg);

if isempty(specs)
    error('realbench:NoDatasetsFound', ...
        'No supported test CSV files were found under %s.', dataset_root);
end

fprintf('Discovered %d dataset(s).\n\n', numel(specs));

output_dir = fullfile(pwd, cfg.OutputDirectory);
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% Preallocate the correct number of columns.
% This is important when one of the collections remains empty.  In the
% previous version, failure_rows={} was a 0-by-0 cell; if all datasets
% succeeded, cell2table(...,3 VariableNames) failed at the very end.
summary_rows = cell(0, numel(summary_variable_names()));
tuning_rows = cell(0, 11);
dataset_rows = cell(0, 10);
failure_rows = cell(0, 3);

for dataset_id = 1:numel(specs)

    spec = specs(dataset_id);

    fprintf('[%d/%d] %s\n', dataset_id, numel(specs), spec.Name);

    try
        test_data = read_benchmark_csv(spec.TestPath);

        train_normal = [];
        train_labelled = [];

        if strlength(spec.TrainNormalPath) > 0 && ...
                isfile(spec.TrainNormalPath)
            train_normal = read_benchmark_csv(spec.TrainNormalPath);
        end

        if strlength(spec.TrainAnomalyPath) > 0 && ...
                isfile(spec.TrainAnomalyPath)
            train_labelled = read_benchmark_csv(spec.TrainAnomalyPath);
        end

        validate_channel_compatibility( ...
            test_data, train_normal, train_labelled, spec.Name);

        % -------------------------------------------------------------
        % Select model structure WITHOUT looking at test labels.
        % -------------------------------------------------------------
        [structure_source, structure_mode] = ...
            choose_structure_source( ...
            test_data, train_normal, train_labelled);

        structure = select_var_structure( ...
            structure_source.Y, cfg);

        % -------------------------------------------------------------
        % Calibrate the two detector multipliers.
        % -------------------------------------------------------------
        calibration = calibrate_thresholds( ...
            structure, train_normal, train_labelled, ...
            test_data, cfg);

        fprintf('  lag structure: %s\n', mat2str(structure.Lags));
        fprintf('  Down gamma   : %.4f (%s)\n', ...
            calibration.DownGamma, calibration.DownMode);
        fprintf('  Patch gamma  : %.4f (%s)\n', ...
            calibration.PatchGamma, calibration.PatchMode);

        % -------------------------------------------------------------
        % Run current Downsampling idea.
        % -------------------------------------------------------------
        down = run_downsampling_method( ...
            test_data.Y, structure, ...
            calibration.DownGamma, cfg);

        down_metrics = binary_metrics( ...
            test_data.Label, down.DetectedMask);

        % -------------------------------------------------------------
        % Run current Patch idea.
        % -------------------------------------------------------------
        patch = run_patch_method( ...
            test_data.Y, structure, ...
            calibration.PatchGamma, cfg);

        patch_metrics = binary_metrics( ...
            test_data.Label, patch.DetectedMask);

        % -------------------------------------------------------------
        % Export summary.
        % -------------------------------------------------------------
        summary_rows(end+1,:) = make_summary_row( ...
            spec.Name, 'Downsampling', ...
            test_data, structure, calibration.DownGamma, ...
            down_metrics, down); %#ok<AGROW>

        summary_rows(end+1,:) = make_summary_row( ...
            spec.Name, 'Patch', ...
            test_data, structure, calibration.PatchGamma, ...
            patch_metrics, patch); %#ok<AGROW>

        tuning_rows(end+1,:) = { ... %#ok<AGROW>
            spec.Name, structure_mode, ...
            mat2str(structure.Lags), structure.BIC, ...
            strjoin(string(structure.PeriodCandidates), ' '), ...
            calibration.DownGamma, calibration.DownMode, ...
            calibration.DownTrainingF1, ...
            calibration.PatchGamma, calibration.PatchMode, ...
            calibration.PatchTrainingF1};

        dataset_rows(end+1,:) = { ... %#ok<AGROW>
            spec.Name, spec.Collection, ...
            string(spec.TestPath), ...
            string(spec.TrainNormalPath), ...
            string(spec.TrainAnomalyPath), ...
            size(test_data.Y,1), size(test_data.Y,2), ...
            sum(test_data.Label), ...
            mean(test_data.Label), ...
            strjoin(test_data.FeatureNames, ',')};

        fprintf('  Down : TP=%d FP=%d TN=%d FN=%d F1=%.4f\n', ...
            down_metrics.TP, down_metrics.FP, ...
            down_metrics.TN, down_metrics.FN, down_metrics.F1);

        fprintf('  Patch: TP=%d FP=%d TN=%d FN=%d F1=%.4f\n\n', ...
            patch_metrics.TP, patch_metrics.FP, ...
            patch_metrics.TN, patch_metrics.FN, patch_metrics.F1);

    catch ME

        warning('realbench:DatasetFailed', ...
            'Dataset %s failed: %s', spec.Name, ME.message);

        failure_rows(end+1,:) = { ... %#ok<AGROW>
            spec.Name, class(ME), ME.message}; %#ok<AGROW>
    end

    % Save a small checkpoint during long benchmark runs.  Only the
    % accumulated result rows are saved; the experimental algorithms are
    % unchanged.  The final XLSX/MAT export below remains authoritative.
    if cfg.CheckpointEvery > 0 && ...
            (mod(dataset_id, cfg.CheckpointEvery) == 0 || ...
             dataset_id == numel(specs))
        checkpoint_file = fullfile(output_dir, ...
            'real_dataset_two_method_checkpoint.mat');

        save(checkpoint_file, ...
            'cfg','specs','dataset_id', ...
            'summary_rows','tuning_rows','dataset_rows','failure_rows', ...
            '-v7.3');
    end
end

assert(size(summary_rows,2) == numel(summary_variable_names()), ...
    'realbench:SummaryColumnMismatch', ...
    'summary_rows has %d columns but %d are required.', ...
    size(summary_rows,2), numel(summary_variable_names()));

assert(size(tuning_rows,2) == 11, ...
    'realbench:TuningColumnMismatch', ...
    'tuning_rows must have 11 columns.');

assert(size(dataset_rows,2) == 10, ...
    'realbench:DatasetInfoColumnMismatch', ...
    'dataset_rows must have 10 columns.');

assert(size(failure_rows,2) == 3, ...
    'realbench:FailureColumnMismatch', ...
    'failure_rows must have 3 columns.');

summary = cell2table(summary_rows, ...
    'VariableNames', summary_variable_names());

tuning = cell2table(tuning_rows, ...
    'VariableNames', { ...
    'Dataset','StructureSource','SelectedLags','StructureBIC', ...
    'DetectedPeriodCandidates', ...
    'DownGamma','DownGammaMode','DownTrainingF1', ...
    'PatchGamma','PatchGammaMode','PatchTrainingF1'});

dataset_info = cell2table(dataset_rows, ...
    'VariableNames', { ...
    'Dataset','Collection','TestPath','TrainNormalPath', ...
    'TrainAnomalyPath','Length','Dimensions','TrueAnomalyPoints', ...
    'Contamination','FeatureNames'});

failures = cell2table(failure_rows, ...
    'VariableNames', {'Dataset','ErrorClass','ErrorMessage'});

xlsx_file = fullfile(output_dir, ...
    'real_dataset_two_method_results_fixed.xlsx');

mat_file = fullfile(output_dir, ...
    'real_dataset_two_method_results_fixed.mat');

if exist(xlsx_file, 'file')
    delete(xlsx_file);
end

writetable(summary, xlsx_file, 'Sheet', 'Summary');
writetable(tuning, xlsx_file, 'Sheet', 'Tuning');
writetable(dataset_info, xlsx_file, 'Sheet', 'DatasetInfo');

if ~isempty(failures)
    writetable(failures, xlsx_file, 'Sheet', 'Failures');
end

save(mat_file, ...
    'cfg', 'specs', 'summary', 'tuning', ...
    'dataset_info', 'failures', '-v7.3');

results = struct();
results.Summary = summary;
results.Tuning = tuning;
results.DatasetInfo = dataset_info;
results.Failures = failures;
results.XLSX = xlsx_file;
results.MAT = mat_file;

fprintf('============================================================\n');
fprintf('Finished.\n');
fprintf('Results: %s\n', xlsx_file);
fprintf('============================================================\n');

end


%% ========================================================================
% Configuration
% ========================================================================

function cfg = default_config()

cfg = struct();

% Empty => run every supported dataset discovered below dataset_root.
% Examples:
%   ["CalIt2","Dodgers"]
%   ["GutenTAG/ecg-noise-10%"]
cfg.DatasetFilter = strings(0,1);

% Common autoregressive structure search.
cfg.BaseOrderCandidates = [1 2 3 5 8 12 16 20];
cfg.MaxSeasonLag = 600;
cfg.NumberOfPeriodCandidates = 4;
cfg.MinimumPeriodCorrelation = 0.15;
cfg.MinimumRowsPerParameter = 5;
cfg.RidgeRelative = 1e-8;
cfg.StructureTrimFraction = 0.10;
cfg.StructureTrimIterations = 3;

% Threshold tuning.
cfg.GammaCandidates = 2.0:0.10:8.0;
cfg.NormalTrainingFalsePositiveRate = 0.005;
cfg.UnsupervisedDownGamma = 3.0;
cfg.UnsupervisedPatchGamma = 4.265;

% Downsampling.
cfg.DownSplitCount = 5;
cfg.DownMaximumDepth = 3;
cfg.DownMinimumTargetRows = 40;
cfg.DownRobustFitIterations = 3;
cfg.DownFitTrimFraction = 0.10;

% Patch.
cfg.PatchWindowLengths = [31 61 121];
cfg.PatchOverlapRatio = 0.50;
cfg.PatchPolynomialOrder = 2;
cfg.PatchIRLSIterations = 6;
cfg.PatchBisquareTuningConstant = 4.685;
cfg.PatchMaximumOuterIterations = 4;
cfg.PatchFitTrimFraction = 0.10;
cfg.PatchRepairTolerance = 1e-6;

% Numerical protection only for divisions.  This is NOT a detector floor.
cfg.MinimumScale = 1e-12;

cfg.OutputDirectory = 'real_dataset_two_method_results_fixed';

% Save accumulated result rows every N datasets.  Set to 0 to disable.
cfg.CheckpointEvery = 10;

end


function out = merge_struct(base, override)

out = base;

if isempty(override)
    return;
end

names = fieldnames(override);

for k = 1:numel(names)
    out.(names{k}) = override.(names{k});
end

end


%% ========================================================================
% Dataset discovery and reading
% ========================================================================

function specs = discover_datasets(root, cfg)

test_files = [ ...
    dir(fullfile(root, '**', 'test.csv')); ...
    dir(fullfile(root, '**', '*.test.csv'))];

% Remove accidental duplicates.
all_paths = strings(numel(test_files),1);

for k = 1:numel(test_files)
    all_paths(k) = string(fullfile( ...
        test_files(k).folder, test_files(k).name));
end

[~, unique_ids] = unique(all_paths, 'stable');
test_files = test_files(unique_ids);

specs = repmat(struct( ...
    'Name',"", ...
    'Collection',"", ...
    'TestPath',"", ...
    'TrainNormalPath',"", ...
    'TrainAnomalyPath',""), 0, 1);

for k = 1:numel(test_files)

    test_path = string(fullfile( ...
        test_files(k).folder, test_files(k).name));

    relative = erase(test_path, string(root) + filesep);
    relative = replace(relative, filesep, "/");

    [folder, filename, ~] = fileparts(test_path);

    if filename == "test"
        relative_folder = erase(string(folder), ...
            string(root) + filesep);
        relative_folder = replace(relative_folder, filesep, "/");
        dataset_name = relative_folder;

        train_normal_path = string(fullfile( ...
            folder, 'train_no_anomaly.csv'));

        train_anomaly_path = string(fullfile( ...
            folder, 'train_anomaly.csv'));

        if ~isfile(train_normal_path)
            train_normal_path = "";
        end

        if ~isfile(train_anomaly_path)
            train_anomaly_path = "";
        end

    else
        % CalIt2 / Dodgers style: *.test.csv
        relative_folder = erase(string(folder), ...
            string(root) + filesep);
        relative_folder = replace(relative_folder, filesep, "/");
        dataset_name = relative_folder + "/" + filename;

        train_normal_path = "";
        train_anomaly_path = "";
    end

    if ~dataset_passes_filter(dataset_name, cfg.DatasetFilter)
        continue;
    end

    parts = split(dataset_name, "/");
    collection = parts(1);

    spec = struct();
    spec.Name = dataset_name;
    spec.Collection = collection;
    spec.TestPath = test_path;
    spec.TrainNormalPath = train_normal_path;
    spec.TrainAnomalyPath = train_anomaly_path;

    specs(end+1,1) = spec; %#ok<AGROW>
end

if ~isempty(specs)
    [~, order] = sort(string({specs.Name}));
    specs = specs(order);
end

end


function tf = dataset_passes_filter(name, filters)

filters = string(filters);

if isempty(filters)
    tf = true;
    return;
end

tf = false;

for k = 1:numel(filters)
    if contains(lower(name), lower(filters(k)))
        tf = true;
        return;
    end
end

end


function data = read_benchmark_csv(path)

T = readtable(path, ...
    'VariableNamingRule','preserve', ...
    'TextType','string');

names = string(T.Properties.VariableNames);
names_lower = lower(names);

label_candidates = [ ...
    "is_anomaly","anomaly","label","labels", ...
    "target","is_outlier","outlier"];

label_id = find(ismember(names_lower, label_candidates), 1);

if isempty(label_id)
    error('realbench:MissingLabel', ...
        'No anomaly-label column was found in %s.', path);
end

time_candidates = ["timestamp","time","datetime","date","index"];
time_ids = find(ismember(names_lower, time_candidates));

numeric_ids = [];

for j = 1:width(T)

    if j == label_id || ismember(j,time_ids)
        continue;
    end

    column = T{:,j};

    if isnumeric(column) || islogical(column)
        numeric_ids(end+1) = j; %#ok<AGROW>
    else
        converted = str2double(string(column));

        if all(isfinite(converted) | ismissing(string(column)))
            T{:,j} = converted;
            numeric_ids(end+1) = j; %#ok<AGROW>
        end
    end
end

if isempty(numeric_ids)
    error('realbench:NoNumericFeatures', ...
        'No numeric time-series channel was found in %s.', path);
end

Y = double(T{:,numeric_ids});
label = double(T{:,label_id});

label(~isfinite(label)) = 0;
label = label ~= 0;

% Fill isolated missing values without using labels.
for j = 1:size(Y,2)
    yj = Y(:,j);

    if any(~isfinite(yj))
        yj = fillmissing(yj,'linear','EndValues','nearest');
    end

    Y(:,j) = yj;
end

if any(~isfinite(Y),'all')
    error('realbench:NonfiniteData', ...
        'Feature matrix remains nonfinite after interpolation: %s', path);
end

data = struct();
data.Y = Y;
data.Label = label(:);
data.FeatureNames = names(numeric_ids);
data.Path = string(path);

end


function validate_channel_compatibility(test_data, train_normal, ...
    train_labelled, dataset_name)

d = size(test_data.Y,2);

if ~isempty(train_normal) && size(train_normal.Y,2) ~= d
    error('realbench:ChannelMismatch', ...
        '%s: train_no_anomaly and test have different dimensions.', ...
        dataset_name);
end

if ~isempty(train_labelled) && size(train_labelled.Y,2) ~= d
    error('realbench:ChannelMismatch', ...
        '%s: train_anomaly and test have different dimensions.', ...
        dataset_name);
end

end


function [source, mode] = choose_structure_source( ...
    test_data, train_normal, train_labelled)

if ~isempty(train_normal)
    source = train_normal;
    mode = "train_no_anomaly";

elseif ~isempty(train_labelled)

    % Preserve the original temporal adjacency.  Robust structure fitting
    % trims the largest residual rows internally; we do not concatenate
    % non-contiguous "normal" rows into an artificial time series.
    source = train_labelled;
    mode = "robust_train_anomaly";

else
    source = test_data;
    mode = "robust_test_without_labels";
end

end


%% ========================================================================
% Structure selection
% ========================================================================

function structure = select_var_structure(Y, cfg)

N = size(Y,1);
d = size(Y,2);

period_candidates = estimate_period_candidates( ...
    Y, cfg.MaxSeasonLag, ...
    cfg.NumberOfPeriodCandidates, ...
    cfg.MinimumPeriodCorrelation);

base_orders = cfg.BaseOrderCandidates;
base_orders = base_orders(base_orders < N/10);

candidate_lag_sets = {};

for p = base_orders
    candidate_lag_sets{end+1} = 1:p; %#ok<AGROW>

    for s = period_candidates(:).'
        seasonal = unique([ ...
            1:p, max(1,s-1), s, min(N-1,s+1)]);
        candidate_lag_sets{end+1} = seasonal; %#ok<AGROW>
    end
end

if isempty(candidate_lag_sets)
    candidate_lag_sets = {[1]};
end

best_bic = Inf;
best_model = [];
best_lags = [];

for candidate_id = 1:numel(candidate_lag_sets)

    lags = candidate_lag_sets{candidate_id};

    if max(lags) >= N-5
        continue;
    end

    [X, T, ~] = make_var_design(Y, lags, []);

    k_parameters = size(X,2)*d;

    if size(X,1) < ...
            cfg.MinimumRowsPerParameter * max(1,size(X,2))
        continue;
    end

    try
        model = fit_var_robust( ...
            X, T, lags, d, cfg.RidgeRelative, ...
            cfg.StructureTrimFraction, ...
            cfg.StructureTrimIterations);

        E = T - X*model.Beta;
        bic = multivariate_bic(E, k_parameters);

        if isfinite(bic) && bic < best_bic
            best_bic = bic;
            best_model = model;
            best_lags = lags;
        end
    catch
    end
end

if isempty(best_model)
    error('realbench:StructureSelectionFailed', ...
        'Could not identify a valid autoregressive structure.');
end

structure = struct();
structure.Lags = best_lags(:).';
structure.BIC = best_bic;
structure.PeriodCandidates = period_candidates(:).';

end


function periods = estimate_period_candidates( ...
    Y, maximum_lag, maximum_count, minimum_correlation)

N = size(Y,1);
maximum_lag = min([maximum_lag, floor(N/4), N-2]);

if maximum_lag < 3
    periods = [];
    return;
end

score = zeros(maximum_lag,1);

for channel_id = 1:size(Y,2)

    x = Y(:,channel_id);
    x = x - median(x);

    % Remove gross scale while preserving periodic shape.
    s = corrected_mad(x);

    if ~isfinite(s) || s <= eps
        s = std(x);
    end

    if ~isfinite(s) || s <= eps
        continue;
    end

    x = max(min(x, 8*s), -8*s);

    nfft = 2^nextpow2(2*N-1);
    f = fft(x,nfft);
    ac = real(ifft(abs(f).^2));
    ac = ac(1:maximum_lag+1);

    if ac(1) <= eps
        continue;
    end

    ac = ac/ac(1);
    score = max(score, abs(ac(2:end)));
end

is_peak = false(maximum_lag,1);

for k = 2:maximum_lag-1
    if score(k) >= score(k-1) && ...
            score(k) >= score(k+1) && ...
            score(k) >= minimum_correlation
        is_peak(k) = true;
    end
end

ids = find(is_peak);

if isempty(ids)
    periods = [];
    return;
end

[~, order] = sort(score(ids),'descend');
ids = ids(order);
ids = ids(1:min(maximum_count,numel(ids)));

% score index 1 corresponds to lag 1.
periods = ids(:).';

end


function [X, T, target_indices] = make_var_design( ...
    Y, lags, requested_targets)

N = size(Y,1);
d = size(Y,2);
maximum_lag = max(lags);

if nargin < 3 || isempty(requested_targets)
    target_indices = (maximum_lag+1:N).';
else
    target_indices = requested_targets(:);
    target_indices = target_indices( ...
        target_indices > maximum_lag & target_indices <= N);
end

n = numel(target_indices);

X = ones(n, 1 + d*numel(lags));

column = 2;

for lag = lags(:).'
    rows = target_indices-lag;
    X(:,column:column+d-1) = Y(rows,:);
    column = column+d;
end

T = Y(target_indices,:);

end


function model = fit_var_robust( ...
    X, T, lags, d, ridge_relative, trim_fraction, iterations)

active = true(size(X,1),1);
Beta = zeros(size(X,2),d);

for iteration_id = 1:max(1,iterations)

    Xa = X(active,:);
    Ta = T(active,:);

    G = Xa.'*Xa;
    lambda = ridge_relative * ...
        max(trace(G)/max(size(G,1),1), 1);

    penalty = eye(size(G));
    penalty(1,1) = 0;

    Beta = (G + lambda*penalty) \ (Xa.'*Ta);

    E = T-X*Beta;
    row_score = sqrt(sum(E.^2,2));

    if trim_fraction <= 0 || iteration_id == iterations
        break;
    end

    keep_count = max(size(X,2)+2, ...
        floor((1-trim_fraction)*numel(row_score)));

    [~, order] = sort(row_score,'ascend');

    active = false(size(active));
    active(order(1:min(keep_count,numel(order)))) = true;
end

model = struct();
model.Beta = Beta;
model.Lags = lags(:).';
model.Dimension = d;

end


function bic = multivariate_bic(E, number_of_parameters)

n = size(E,1);
d = size(E,2);

if n <= 0
    bic = Inf;
    return;
end

Sigma = (E.'*E)/n;
Sigma = Sigma + 1e-12*max(1,trace(Sigma)/max(d,1))*eye(d);

eigenvalues = eig((Sigma+Sigma.')/2);
eigenvalues = max(real(eigenvalues), realmin);

logdet = sum(log(eigenvalues));

bic = n*logdet + number_of_parameters*log(n);

end


%% ========================================================================
% Threshold calibration
% ========================================================================

function calibration = calibrate_thresholds( ...
    structure, train_normal, train_labelled, test_data, cfg)

calibration = struct();
calibration.DownTrainingF1 = NaN;
calibration.PatchTrainingF1 = NaN;

if ~isempty(train_normal)

    normal_model = fit_model_on_full_record( ...
        train_normal.Y, structure.Lags, cfg, ...
        cfg.StructureTrimFraction);

elseif ~isempty(train_labelled)

    % Preserve sequence adjacency and rely on robust fitting; labels are
    % used later only to choose gamma.
    normal_model = fit_model_on_full_record( ...
        train_labelled.Y, structure.Lags, cfg, ...
        cfg.StructureTrimFraction);

else
    normal_model = [];
end

if ~isempty(train_labelled)

    % Tune on labelled TRAINING data only.
    down_score = global_residual_score( ...
        train_labelled.Y, normal_model, ...
        structure.Lags, cfg);

    patch_score = patch_residual_score( ...
        train_labelled.Y, normal_model, ...
        structure.Lags, cfg);

    [calibration.DownGamma, calibration.DownTrainingF1] = ...
        tune_gamma_by_f1( ...
        down_score, train_labelled.Label, ...
        cfg.GammaCandidates);

    [calibration.PatchGamma, calibration.PatchTrainingF1] = ...
        tune_gamma_by_f1( ...
        patch_score.Score, train_labelled.Label, ...
        cfg.GammaCandidates);

    calibration.DownMode = "labelled_training_F1";
    calibration.PatchMode = "labelled_training_F1";

elseif ~isempty(train_normal)

    down_score = global_residual_score( ...
        train_normal.Y, normal_model, ...
        structure.Lags, cfg);

    patch_score = patch_residual_score( ...
        train_normal.Y, normal_model, ...
        structure.Lags, cfg);

    calibration.DownGamma = training_quantile_gamma( ...
        down_score, cfg.NormalTrainingFalsePositiveRate, ...
        cfg.GammaCandidates);

    calibration.PatchGamma = training_quantile_gamma( ...
        patch_score.Score, ...
        cfg.NormalTrainingFalsePositiveRate, ...
        cfg.GammaCandidates);

    calibration.DownMode = "normal_training_FPR";
    calibration.PatchMode = "normal_training_FPR";

else
    % No test labels are used for calibration.
    calibration.DownGamma = cfg.UnsupervisedDownGamma;
    calibration.PatchGamma = cfg.UnsupervisedPatchGamma;

    calibration.DownMode = "fixed_unsupervised";
    calibration.PatchMode = "fixed_unsupervised";
end

end


function [gamma, best_f1] = tune_gamma_by_f1( ...
    score, labels, candidates)

score = score(:);
labels = logical(labels(:));

valid = isfinite(score);

best_f1 = -Inf;
gamma = candidates(1);

for g = candidates(:).'

    detected = false(size(labels));
    detected(valid) = score(valid) > g;

    metrics = binary_metrics(labels,detected);

    % Tie break toward the larger threshold (fewer false positives).
    if metrics.F1 > best_f1 + 1e-12 || ...
            (abs(metrics.F1-best_f1)<=1e-12 && g>gamma)
        best_f1 = metrics.F1;
        gamma = g;
    end
end

end


function gamma = training_quantile_gamma(score, alpha, candidates)

score = score(isfinite(score));

if isempty(score)
    gamma = 3;
    return;
end

q = simple_quantile(score, 1-alpha);

[~, id] = min(abs(candidates-q));
gamma = candidates(id);

end


%% ========================================================================
% Downsampling
% ========================================================================

function result = run_downsampling_method(Y, structure, gamma, cfg)

lags = structure.Lags;
maximum_lag = max(lags);
targets = (maximum_lag+1:size(Y,1)).';

search = downsampling_search( ...
    Y, targets, lags, cfg, 0, []);

if ~search.Found
    model = fit_model_on_full_record( ...
        Y, lags, cfg, cfg.DownFitTrimFraction);
    accepted_targets = targets;
    accepted_path = [];
else
    model = search.Model;
    accepted_targets = search.Targets;
    accepted_path = search.Path;
end

[prediction, residual, valid] = ...
    predict_var_complete(Y, model, lags);

[score, center, scale] = standardized_global_residual( ...
    residual, valid, cfg.MinimumScale);

detected = valid & score > gamma;

result = struct();
result.DetectedMask = detected;
result.Score = score;
result.Prediction = prediction;
result.Residual = residual;
result.Center = center;
result.Scale = scale;
result.AcceptedTargets = accepted_targets;
result.AcceptedPath = accepted_path;
result.Aux1 = numel(accepted_targets);
result.Aux2 = search.NodesEvaluated;

end


function result = downsampling_search( ...
    Y, parent_targets, lags, cfg, depth, path)

result = struct( ...
    'Found',false, ...
    'Model',[], ...
    'Targets',[], ...
    'Path',[], ...
    'Criterion',Inf, ...
    'NodesEvaluated',0);

K = cfg.DownSplitCount;
M = numel(parent_targets);

candidate = repmat(struct( ...
    'Model',[], ...
    'Targets',[], ...
    'Criterion',Inf, ...
    'ChildID',0), K, 1);

for child_id = 1:K

    targets = parent_targets(child_id:K:M);

    if numel(targets) < cfg.DownMinimumTargetRows
        continue;
    end

    [X,T,targets] = make_var_design(Y,lags,targets);

    if size(X,1) < max(cfg.DownMinimumTargetRows,size(X,2)+2)
        continue;
    end

    try
        model = fit_var_robust( ...
            X,T,lags,size(Y,2),cfg.RidgeRelative, ...
            cfg.DownFitTrimFraction, ...
            cfg.DownRobustFitIterations);

        E = T-X*model.Beta;

        criterion = robust_child_criterion(E);

        candidate(child_id).Model = model;
        candidate(child_id).Targets = targets;
        candidate(child_id).Criterion = criterion;
        candidate(child_id).ChildID = child_id;

        result.NodesEvaluated = result.NodesEvaluated+1;
    catch
    end
end

criteria = [candidate.Criterion];
finite_ids = find(isfinite(criteria));

if isempty(finite_ids)
    return;
end

[~, order_local] = sort(criteria(finite_ids),'ascend');
visit_ids = finite_ids(order_local);

best_id = visit_ids(1);

% At the deepest allowed level, accept the cleanest child.
if depth+1 >= cfg.DownMaximumDepth
    result.Found = true;
    result.Model = candidate(best_id).Model;
    result.Targets = candidate(best_id).Targets;
    result.Path = [path,best_id];
    result.Criterion = candidate(best_id).Criterion;
    return;
end

% Try the cleanest candidate first. If further splitting becomes too short,
% accept the current candidate. This mirrors the "search clean child first"
% logic while avoiding a noise-free RSS threshold that is inappropriate for
% real benchmark data.
for order_id = 1:numel(visit_ids)

    child_id = visit_ids(order_id);
    child_targets = candidate(child_id).Targets;

    if floor(numel(child_targets)/K) < ...
            cfg.DownMinimumTargetRows

        result.Found = true;
        result.Model = candidate(child_id).Model;
        result.Targets = child_targets;
        result.Path = [path,child_id];
        result.Criterion = candidate(child_id).Criterion;
        return;
    end

    descendant = downsampling_search( ...
        Y, child_targets, lags, cfg, ...
        depth+1, [path,child_id]);

    result.NodesEvaluated = ...
        result.NodesEvaluated + descendant.NodesEvaluated;

    if descendant.Found
        result = descendant;
        result.NodesEvaluated = ...
            result.NodesEvaluated + 1;
        return;
    end
end

result.Found = true;
result.Model = candidate(best_id).Model;
result.Targets = candidate(best_id).Targets;
result.Path = [path,best_id];
result.Criterion = candidate(best_id).Criterion;

end


function value = robust_child_criterion(E)

row_energy = sum(E.^2,2);
row_energy = row_energy(isfinite(row_energy));

if isempty(row_energy)
    value = Inf;
    return;
end

value = median(row_energy);

end


%% ========================================================================
% Patch
% ========================================================================

function result = run_patch_method(Y_original, structure, gamma, cfg)

Y_repaired = Y_original;
previous_detected = false(size(Y_original,1),1);
converged = false;

final_score = nan(size(Y_original,1),1);
final_prediction = nan(size(Y_original));
final_residual = nan(size(Y_original));
final_trend = zeros(size(Y_original));

for iteration_id = 1:cfg.PatchMaximumOuterIterations

    model = fit_model_on_full_record( ...
        Y_repaired, structure.Lags, cfg, ...
        cfg.PatchFitTrimFraction);

    [prediction_from_repaired,~,valid] = ...
        predict_var_complete( ...
        Y_repaired, model, structure.Lags);

    residual_against_original = ...
        Y_original - prediction_from_repaired;

    patch = local_patch_score_from_residual( ...
        residual_against_original, valid, cfg);

    detected = valid & patch.Score > gamma;

    Y_new = Y_repaired;

    for channel_id = 1:size(Y_original,2)

        replacement = ...
            prediction_from_repaired(:,channel_id) + ...
            patch.ExpectedResidual(:,channel_id);

        ids = detected & isfinite(replacement);
        Y_new(ids,channel_id) = replacement(ids);
    end

    relative_change = norm(Y_new-Y_repaired,'fro') / ...
        max(norm(Y_repaired,'fro'),eps);

    same_set = isequal(detected,previous_detected);

    Y_repaired = Y_new;
    previous_detected = detected;

    final_score = patch.Score;
    final_prediction = prediction_from_repaired;
    final_residual = residual_against_original;
    final_trend = patch.ExpectedResidual;

    if iteration_id >= 2 && ...
            same_set && relative_change <= cfg.PatchRepairTolerance
        converged = true;
        break;
    end
end

result = struct();
result.DetectedMask = previous_detected;
result.Score = final_score;
result.Prediction = final_prediction;
result.Residual = final_residual;
result.ExpectedResidual = final_trend;
result.RepairedY = Y_repaired;
result.Aux1 = iteration_id;
result.Aux2 = double(converged);

end


function out = patch_residual_score( ...
    Y, model, lags, cfg)

[~, residual, valid] = ...
    predict_var_complete(Y,model,lags);

out = local_patch_score_from_residual( ...
    residual,valid,cfg);

end


function out = local_patch_score_from_residual( ...
    residual, valid, cfg)

N = size(residual,1);
d = size(residual,2);

% Memory-efficient fusion: with 50% overlapping windows every point is
% covered by only a few windows.  We accumulate window estimates instead
% of allocating an N-by-number_of_windows array (important for Dodgers,
% which has about 50k samples).
score_by_scale = nan(N,numel(cfg.PatchWindowLengths));
trend_by_scale = nan(N,d,numel(cfg.PatchWindowLengths));

for scale_id = 1:numel(cfg.PatchWindowLengths)

    L = min(cfg.PatchWindowLengths(scale_id),N);

    if L < cfg.PatchPolynomialOrder+3
        continue;
    end

    if mod(L,2)==0
        L = max(cfg.PatchPolynomialOrder+3,L-1);
    end

    stride = max(1,round(L*(1-cfg.PatchOverlapRatio)));
    starts = make_window_starts(N,L,stride);

    score_sum = zeros(N,1);
    score_count = zeros(N,1);

    trend_sum = zeros(N,d);
    trend_count = zeros(N,d);

    for window_id = 1:numel(starts)

        idx = starts(window_id):(starts(window_id)+L-1);

        if sum(valid(idx)) < cfg.PatchPolynomialOrder+3
            continue;
        end

        channel_score = nan(L,d);

        for channel_id = 1:d

            y = residual(idx,channel_id);

            [trend,scale] = robust_polynomial_trend( ...
                y,cfg.PatchPolynomialOrder, ...
                cfg.PatchIRLSIterations, ...
                cfg.PatchBisquareTuningConstant, ...
                cfg.MinimumScale);

            good_trend = isfinite(trend);
            active_idx = idx(good_trend);

            trend_sum(active_idx,channel_id) = ...
                trend_sum(active_idx,channel_id) + ...
                trend(good_trend);

            trend_count(active_idx,channel_id) = ...
                trend_count(active_idx,channel_id) + 1;

            channel_score(:,channel_id) = ...
                abs(y-trend)/max(scale,cfg.MinimumScale);
        end

        window_score = max(channel_score,[],2,'omitnan');
        good_score = isfinite(window_score);
        active_idx = idx(good_score);

        score_sum(active_idx) = ...
            score_sum(active_idx) + window_score(good_score);

        score_count(active_idx) = ...
            score_count(active_idx) + 1;
    end

    scale_score = nan(N,1);
    covered = score_count>0;
    scale_score(covered) = ...
        score_sum(covered)./score_count(covered);

    score_by_scale(:,scale_id) = scale_score;

    for channel_id = 1:d
        covered = trend_count(:,channel_id)>0;
        tmp = nan(N,1);
        tmp(covered) = ...
            trend_sum(covered,channel_id) ./ ...
            trend_count(covered,channel_id);
        trend_by_scale(:,channel_id,scale_id) = tmp;
    end
end

score = max(score_by_scale,[],2,'omitnan');
expected_residual = median(trend_by_scale,3,'omitnan');

score(~valid) = NaN;

for channel_id = 1:d
    missing = ~isfinite(expected_residual(:,channel_id));
    expected_residual(missing,channel_id) = 0;
end

out = struct();
out.Score = score;
out.ExpectedResidual = expected_residual;

end


function [trend,scale] = robust_polynomial_trend( ...
    y, order, iterations, tuning_constant, minimum_scale)

y = y(:);
L = numel(y);

x = linspace(-1,1,L).';

X = ones(L,order+1);

for p = 1:order
    X(:,p+1) = x.^p;
end

valid = isfinite(y);

if sum(valid) < order+1
    trend = repmat(median(y(valid),'omitnan'),L,1);
    scale = corrected_mad(y(valid));
    return;
end

coeff = X(valid,:) \ y(valid);

for iteration_id = 1:max(1,iterations)

    fitted = X*coeff;
    e = y-fitted;

    scale = corrected_mad(e(valid));

    if ~isfinite(scale) || scale < minimum_scale
        scale = max(std(e(valid)),minimum_scale);
    end

    u = e/(tuning_constant*scale);

    w = zeros(L,1);
    inside = valid & abs(u)<1;
    w(inside) = (1-u(inside).^2).^2;

    if sum(w>0)<order+1
        break;
    end

    sw = sqrt(w);
    Xw = bsxfun(@times,X,sw);
    yw = y.*sw;

    new_coeff = Xw \ yw;

    if norm(new_coeff-coeff) <= ...
            1e-8*max(1,norm(coeff))
        coeff = new_coeff;
        break;
    end

    coeff = new_coeff;
end

trend = X*coeff;
e = y-trend;
scale = corrected_mad(e(valid));

if ~isfinite(scale) || scale<minimum_scale
    scale = max(std(e(valid)),minimum_scale);
end

end


function starts = make_window_starts(N,L,stride)

last_start = N-L+1;

if last_start < 1
    starts = 1;
    return;
end

starts = 1:stride:last_start;

if starts(end) ~= last_start
    starts(end+1) = last_start;
end

starts = unique(starts,'stable');

end


%% ========================================================================
% Shared predictor / residual helpers
% ========================================================================

function model = fit_model_on_full_record( ...
    Y,lags,cfg,trim_fraction)

[X,T,~] = make_var_design(Y,lags,[]);

if size(X,1) <= size(X,2)+1
    error('realbench:TooFewRowsForModel', ...
        'Too few rows to estimate selected VAR structure.');
end

model = fit_var_robust( ...
    X,T,lags,size(Y,2),cfg.RidgeRelative, ...
    trim_fraction,cfg.StructureTrimIterations);

end


function [prediction,residual,valid] = ...
    predict_var_complete(Y,model,lags)

N = size(Y,1);
d = size(Y,2);

prediction = nan(N,d);
residual = nan(N,d);
valid = false(N,1);

[X,~,targets] = make_var_design(Y,lags,[]);

P = X*model.Beta;

prediction(targets,:) = P;
residual(targets,:) = Y(targets,:)-P;
valid(targets) = all(isfinite(P),2);

end


function score = global_residual_score(Y,model,lags,cfg)

[~,residual,valid] = ...
    predict_var_complete(Y,model,lags);

score = standardized_global_residual( ...
    residual,valid,cfg.MinimumScale);

end


function [score,center,scale] = ...
    standardized_global_residual( ...
    residual,valid,minimum_scale)

d = size(residual,2);

center = zeros(1,d);
scale = ones(1,d);
z = nan(size(residual));

for channel_id = 1:d

    r = residual(valid,channel_id);
    r = r(isfinite(r));

    center(channel_id) = median(r);
    scale(channel_id) = corrected_mad(r);

    if ~isfinite(scale(channel_id)) || ...
            scale(channel_id)<minimum_scale
        scale(channel_id) = ...
            max(std(r),minimum_scale);
    end

    z(:,channel_id) = ...
        abs(residual(:,channel_id)-center(channel_id)) / ...
        scale(channel_id);
end

score = max(z,[],2,'omitnan');
score(~valid) = NaN;

end


function value = corrected_mad(x)

x = x(:);
x = x(isfinite(x));

if isempty(x)
    value = NaN;
    return;
end

m = median(x);
value = 1.482602218505602 * median(abs(x-m));

end


function value = simple_quantile(x,q)

x = sort(x(isfinite(x)));

if isempty(x)
    value = NaN;
    return;
end

q = min(max(q,0),1);

position = 1+(numel(x)-1)*q;
lo = floor(position);
hi = ceil(position);

if lo==hi
    value = x(lo);
else
    a = position-lo;
    value = (1-a)*x(lo)+a*x(hi);
end

end


%% ========================================================================
% Metrics and output
% ========================================================================

function m = binary_metrics(true_label,detected)

true_label = logical(true_label(:));
detected = logical(detected(:));

if numel(true_label) ~= numel(detected)
    error('realbench:MetricLengthMismatch', ...
        'True and detected masks have different lengths.');
end

TP = sum(true_label & detected);
TN = sum(~true_label & ~detected);
FP = sum(~true_label & detected);
FN = sum(true_label & ~detected);

precision = safe_divide(TP,TP+FP);
recall = safe_divide(TP,TP+FN);
specificity = safe_divide(TN,TN+FP);
f1 = safe_divide(2*precision*recall,precision+recall);
accuracy = safe_divide(TP+TN,numel(true_label));
balanced = mean([recall,specificity],'omitnan');

den = sqrt( ...
    (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN));

if den>0
    mcc = (TP*TN-FP*FN)/den;
else
    mcc = NaN;
end

m = struct();
m.TP = TP;
m.TN = TN;
m.FP = FP;
m.FN = FN;
m.Precision = precision;
m.Recall = recall;
m.Specificity = specificity;
m.F1 = f1;
m.Accuracy = accuracy;
m.BalancedAccuracy = balanced;
m.MCC = mcc;

end


function value = safe_divide(a,b)

if b==0
    value = NaN;
else
    value = a/b;
end

end


function row = make_summary_row( ...
    dataset_name,method_name,test_data,structure,gamma,metrics,method)

row = { ...
    dataset_name, method_name, ...
    size(test_data.Y,1), size(test_data.Y,2), ...
    sum(test_data.Label), gamma, ...
    mat2str(structure.Lags), ...
    metrics.TP, metrics.TN, metrics.FP, metrics.FN, ...
    metrics.Precision, metrics.Recall, metrics.Specificity, ...
    metrics.F1, metrics.Accuracy, ...
    metrics.BalancedAccuracy, metrics.MCC, ...
    sum(method.DetectedMask), method.Aux1, method.Aux2};

end


function names = summary_variable_names()

names = { ...
    'Dataset','Method','Length','Dimensions', ...
    'TrueAnomalyPoints','Gamma','SelectedLags', ...
    'TP','TN','FP','FN','Precision','Recall','Specificity', ...
    'F1','Accuracy','BalancedAccuracy','MCC', ...
    'DetectedPoints','MethodAux1','MethodAux2'};

end
